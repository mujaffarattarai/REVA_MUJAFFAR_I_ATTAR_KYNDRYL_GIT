"""
Wedding Planner UI - Flask Professional with Row Input
=======================================================

Enhanced Flask UI with professional dark blue & gold color scheme.
Now includes both form input and natural language row input.

Run:
    python wedding_planner_flask_professional_roweinput.py
    
Then visit: http://localhost:5000
"""

import asyncio
import os
import re
from pathlib import Path
from typing import Any, Dict, Tuple

from flask import Flask, render_template_string, request, jsonify
from dotenv import load_dotenv

from langchain.agents import AgentState, create_agent
from langchain.messages import HumanMessage, ToolMessage
from langchain.tools import ToolRuntime, tool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.types import Command

from mcp.shared.exceptions import McpError
from mcp.types import CallToolResult, TextContent

from tavily import TavilyClient
from langchain_community.utilities import SQLDatabase


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

load_dotenv()

MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-5-nano")
MCP_TRAVEL_URL = os.getenv("MCP_TRAVEL_URL", "https://mcp.kiwi.com")
SQLITE_DB_PATH = os.getenv("SQLITE_DB_PATH", "notebooks/module-2/resources/Chinook.db")

MAX_WEB_SEARCHES = 12
MAX_MCP_RETRIES = 3
RECURSION_LIMIT = 40

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


# ---------------------------------------------------------------------------
# Natural Language Parser
# ---------------------------------------------------------------------------

GENRES = [
    "jazz", "classical", "pop", "bollywood", "rock",
    "reggae", "electronic", "indie"
]


def parse_row_input(text: str) -> Tuple[str, str, str, str, str]:
    """
    Parse natural language row input like:
    "I am travelling from mumbai to jaipur with 100 people and music like genre is jazz"
    OR
    "I'm from Mumbai and I'd like a wedding destination Jaipur for 100 guests Jazz-genre"
    
    Returns: (origin, destination, guest_count, genre, error_message)
    """
    text = text.lower().strip()
    error = None
    origin = None
    destination = None
    guest_count = "100"
    genre = None
    
    # Extract origin (from X)
    # Handles: "from mumbai", "from Mumbai and", "from london to"
    from_match = re.search(r'from\s+([a-z\s]+?)(?:\s+(?:to|and|with))', text)
    if from_match:
        origin = from_match.group(1).strip().title()
    
    # Extract destination - try multiple patterns
    # Pattern 1: "to X" (to jaipur, to Paris)
    to_match = re.search(r'\bto\s+([a-z\s]+?)(?:\s+(?:with|and|for|with))', text)
    if to_match:
        destination = to_match.group(1).strip().title()
    
    # Pattern 2: "destination X" (destination Jaipur, destination Paris)
    if not destination:
        dest_match = re.search(r'destination\s+([a-z\s]+?)(?:\s+(?:for|with|and)|$)', text)
        if dest_match:
            destination = dest_match.group(1).strip().title()
    
    # Pattern 3: "wedding destination X" (wedding destination Jaipur)
    if not destination:
        wedding_dest_match = re.search(r'wedding\s+destination\s+([a-z\s]+?)(?:\s+(?:for|with|and)|$)', text)
        if wedding_dest_match:
            destination = wedding_dest_match.group(1).strip().title()
    
    # Pattern 4: "in X" (in Jaipur, in Paris) - last resort if no "to" or "destination"
    if not destination:
        in_match = re.search(r'\bin\s+([a-z\s]+?)(?:\s+(?:for|with|and)|$)', text)
        if in_match:
            destination = in_match.group(1).strip().title()
    
    # Extract guest count (numbers followed by people/guests/person)
    count_match = re.search(r'(\d+)\s+(?:people|guests|person)', text)
    if count_match:
        guest_count = count_match.group(1)
    
    # Extract genre - exact match first
    for g in GENRES:
        if g in text:
            genre = g
            break
    
    # If no exact genre match, try "genre" keyword
    if not genre:
        genre_match = re.search(r'genre(?:\s+is)?\s+([a-z]+)', text)
        if genre_match:
            potential_genre = genre_match.group(1)
            if potential_genre in GENRES:
                genre = potential_genre
    
    # Validate
    if not origin:
        error = "❌ Could not find origin. Try: 'from Mumbai' or 'I'm from Mumbai'"
    elif not destination:
        error = "❌ Could not find destination. Try: 'to Jaipur' or 'destination Jaipur' or 'wedding destination Jaipur'"
    elif not genre:
        error = f"❌ Genre not found. Use one of: {', '.join(GENRES[:5])}... or 'jazz', 'classical', 'pop', 'bollywood', 'rock'"
    
    return origin or "", destination or "", guest_count, genre or "", error


# ---------------------------------------------------------------------------
# MCP error handling
# ---------------------------------------------------------------------------

RETRYABLE_MCP_CODES = {-32603}


class RetryMCPInterceptor:
    def __init__(self, max_retries: int = MAX_MCP_RETRIES):
        self.max_retries = max_retries

    async def __call__(self, request, handler):
        last_error: Exception | None = None

        for attempt in range(self.max_retries):
            try:
                return await handler(request)
            except McpError as exc:
                last_error = exc
                if exc.error.code not in RETRYABLE_MCP_CODES:
                    return CallToolResult(
                        content=[
                            TextContent(
                                type="text",
                                text=f"Tool call failed (non-retryable): {exc}",
                            )
                        ],
                        isError=False,
                    )
            except Exception as exc:
                last_error = exc

            if attempt < self.max_retries - 1:
                await asyncio.sleep(2**attempt)

        return CallToolResult(
            content=[
                TextContent(
                    type="text",
                    text=f"Tool call failed after {self.max_retries} attempts: {last_error}",
                )
            ],
            isError=False,
        )


# ---------------------------------------------------------------------------
# MCP client
# ---------------------------------------------------------------------------

mcp_client = None


def get_mcp_client():
    global mcp_client
    if mcp_client is None:
        mcp_client = MultiServerMCPClient(
            {
                "travel_server": {
                    "transport": "streamable_http",
                    "url": MCP_TRAVEL_URL,
                }
            },
            tool_interceptors=[RetryMCPInterceptor()],
        )
    return mcp_client


# ---------------------------------------------------------------------------
# Web-search tool
# ---------------------------------------------------------------------------

tavily_client = TavilyClient()


@tool
def web_search(
    query: str,
    search_number: int,
    max_search_number: int = MAX_WEB_SEARCHES,
) -> Dict[str, Any]:
    """Search the web for wedding venue information."""
    if search_number > max_search_number:
        return {
            "message": "Search limit reached. Stop searching and summarize the best findings available."
        }

    try:
        return tavily_client.search(query)
    except Exception as exc:
        return {"error": str(exc)}


# ---------------------------------------------------------------------------
# SQL tool
# ---------------------------------------------------------------------------

db_path = Path(SQLITE_DB_PATH)
if not db_path.exists():
    raise FileNotFoundError(f"Database not found: {db_path}")

db = SQLDatabase.from_uri(f"sqlite:///{SQLITE_DB_PATH}")


@tool
def query_playlist_db(query: str) -> str:
    """Execute a SQL query against the wedding playlist database."""
    try:
        return db.run(query)
    except Exception as exc:
        return f"Error querying database: {exc}"


# ---------------------------------------------------------------------------
# Shared state
# ---------------------------------------------------------------------------

class WeddingState(AgentState):
    """Information shared between the coordinator and specialist agents."""

    origin: str
    destination: str
    guest_count: str
    genre: str


# ---------------------------------------------------------------------------
# Specialist agents
# ---------------------------------------------------------------------------

def build_travel_agent(mcp_tools):
    return create_agent(
        model=MODEL_NAME,
        tools=mcp_tools,
        system_prompt="""
You are a travel specialist for a destination wedding.

Your task:
- Search for flights from the given origin to the destination wedding location.
- Do not ask follow-up questions.
- Find the best options using:
  1. Lowest economy price
  2. Shortest duration
  3. A sensible time of year for a wedding at the destination

Only look for one-way, one-ticket options.

You may make multiple searches if needed.
If an MCP tool fails, returns malformed output, or provides unusable
flight results, try the tool again.

Return a concise shortlist of the best flight options with useful details.
IMPORTANT: Return SPECIFIC flight details with prices, airlines, times, durations.
Do NOT return generic text. Include actual flight data.
""",
    )


def build_venue_agent():
    return create_agent(
        model=MODEL_NAME,
        tools=[web_search],
        system_prompt=f"""
You are a wedding venue specialist.

Search for venues in the requested destination and guest capacity.

Do not ask follow-up questions.

Rank options using:
1. Lowest price
2. Exact or closest suitable capacity
3. Highest-quality reviews

You may make multiple searches.
You have a maximum of {MAX_WEB_SEARCHES} web searches.

When the search limit is reached, stop searching and summarize the
best options found so far.

Return SPECIFIC venue details with names, prices, capacity, ratings.
""",
    )


def build_playlist_agent():
    return create_agent(
        model=MODEL_NAME,
        tools=[query_playlist_db],
        system_prompt="""
You are a wedding playlist specialist.

Use the SQL database to curate a playlist for the requested genre.

Requirements:
- First discover the database schema before writing data queries.
- Select suitable wedding tracks.
- Calculate total playlist duration.
- Calculate total playlist cost when the database provides song prices.
- If a query fails, inspect the error and correct the query.
- Keep trying until you can produce a useful playlist.

Return SPECIFIC song details with artists, durations, costs.
""",
    )


# ---------------------------------------------------------------------------
# Coordinator tools
# ---------------------------------------------------------------------------

def build_specialist_tools(travel_agent, venue_agent, playlist_agent):
    @tool
    async def search_flights(runtime: ToolRuntime) -> str:
        """Ask the travel specialist to find flights."""
        origin = runtime.state["origin"]
        destination = runtime.state["destination"]

        response = await travel_agent.ainvoke(
            {
                "messages": [
                    HumanMessage(
                        content=f"Find flights from {origin} to {destination}. Return SPECIFIC details: airlines, prices, times, durations."
                    )
                ]
            }
        )

        return response["messages"][-1].content

    @tool
    def search_venues(runtime: ToolRuntime) -> str:
        """Ask the venue specialist to find suitable wedding venues."""
        destination = runtime.state["destination"]
        capacity = runtime.state["guest_count"]

        query = f"Find wedding venues in {destination} for {capacity} guests. Return SPECIFIC venue names, prices, capacities, ratings."

        response = venue_agent.invoke(
            {"messages": [HumanMessage(content=query)]}
        )

        return response["messages"][-1].content

    @tool
    def suggest_playlist(runtime: ToolRuntime) -> str:
        """Ask the playlist specialist to curate the wedding playlist."""
        genre = runtime.state["genre"]

        query = f"Find {genre} tracks for a wedding playlist. Return SPECIFIC song names, artists, durations, costs."

        response = playlist_agent.invoke(
            {"messages": [HumanMessage(content=query)]}
        )

        return response["messages"][-1].content

    @tool
    def update_state(
        origin: str,
        destination: str,
        guest_count: str,
        genre: str,
        runtime: ToolRuntime,
    ) -> Command:
        """Save all required wedding details into shared agent state."""
        return Command(
            update={
                "origin": origin,
                "destination": destination,
                "guest_count": guest_count,
                "genre": genre,
                "messages": [
                    ToolMessage(
                        content="Wedding state successfully updated.",
                        tool_call_id=runtime.tool_call_id,
                    )
                ],
            }
        )

    return [
        search_flights,
        search_venues,
        suggest_playlist,
        update_state,
    ]


# ---------------------------------------------------------------------------
# Coordinator
# ---------------------------------------------------------------------------

def build_coordinator(specialist_tools):
    return create_agent(
        model=MODEL_NAME,
        tools=specialist_tools,
        state_schema=WeddingState,
        system_prompt="""
You are the main AI wedding coordinator.

Workflow:
1. Read the user's wedding request.
2. Identify:
   - origin
   - destination
   - guest count
   - music genre
3. When all four values are known, call update_state.
4. Wait for the state update to complete.
5. Delegate:
   - flights -> travel specialist
   - venues -> venue specialist
   - playlist -> playlist specialist
6. Review all specialist results.
7. Produce one concise, coordinated wedding recommendation.

Do not ask unnecessary follow-up questions.
If information can reasonably be inferred from the request, use it.
""",
    )


# ---------------------------------------------------------------------------
# Main Wedding Planner Function
# ---------------------------------------------------------------------------

async def run_wedding_planner(user_request: str) -> str:
    """Build all agents and process one wedding-planning request."""
    mcp_client = get_mcp_client()
    mcp_tools = await mcp_client.get_tools()

    travel_agent = build_travel_agent(mcp_tools)
    venue_agent = build_venue_agent()
    playlist_agent = build_playlist_agent()

    specialist_tools = build_specialist_tools(
        travel_agent,
        venue_agent,
        playlist_agent,
    )

    coordinator = build_coordinator(specialist_tools)

    response = await coordinator.ainvoke(
        {"messages": [HumanMessage(content=user_request)]},
        config={
            "tags": ["WeddingPlanner"],
            "recursion_limit": RECURSION_LIMIT,
        },
    )

    return response["messages"][-1].content


# ---------------------------------------------------------------------------
# HTML Templates - Professional Dark Blue & Gold with Row Input
# ---------------------------------------------------------------------------

INDEX_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>💍 AI Wedding Planner - Professional</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        :root {
            --primary-dark: #1a2f4a;
            --primary-light: #2d4a6f;
            --gold: #d4a574;
            --gold-light: #e8c9a0;
            --text-dark: #1a1a1a;
            --text-light: #f5f5f5;
            --border: #3d5a7f;
            --success: #2ecc71;
            --error: #e74c3c;
            --warning: #f39c12;
        }
        
        body {
            font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
            background: linear-gradient(135deg, var(--primary-dark) 0%, #0f1c2e 100%);
            color: var(--text-light);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            width: 100%;
        }
        
        header {
            text-align: center;
            margin-bottom: 40px;
            animation: slideDown 0.6s ease;
        }
        
        header h1 {
            font-size: 3rem;
            margin-bottom: 10px;
            color: var(--gold);
            text-shadow: 2px 2px 8px rgba(0,0,0,0.4);
            letter-spacing: 2px;
        }
        
        header p {
            font-size: 1.1rem;
            color: var(--gold-light);
            opacity: 0.9;
        }
        
        .divider {
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--gold), transparent);
            margin: 30px 0;
        }
        
        .main-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .card {
            background: rgba(45, 74, 111, 0.5);
            border: 1px solid var(--border);
            border-radius: 15px;
            padding: 30px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            transition: all 0.3s ease;
            animation: fadeIn 0.6s ease 0.1s both;
        }
        
        .card:hover {
            border-color: var(--gold);
            box-shadow: 0 12px 48px rgba(212, 165, 116, 0.15);
            transform: translateY(-5px);
        }
        
        .card h2 {
            color: var(--gold);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.4rem;
            letter-spacing: 1px;
        }
        
        .tab-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 2px solid var(--border);
            padding-bottom: 15px;
        }
        
        .tab-btn {
            padding: 10px 20px;
            background: transparent;
            border: none;
            color: var(--gold-light);
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: 600;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
            margin-bottom: -17px;
        }
        
        .tab-btn.active {
            color: var(--gold);
            border-bottom-color: var(--gold);
        }
        
        .tab-btn:hover:not(.active) {
            color: var(--text-light);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: var(--gold-light);
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1.5px solid var(--border);
            background: rgba(26, 47, 74, 0.6);
            color: var(--text-light);
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: inherit;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        input::placeholder, textarea::placeholder {
            color: rgba(232, 201, 160, 0.5);
        }
        
        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--gold);
            background: rgba(26, 47, 74, 0.8);
            box-shadow: 0 0 12px rgba(212, 165, 116, 0.2);
        }
        
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, var(--gold) 0%, #c9905f 100%);
            color: var(--primary-dark);
            border: none;
            border-radius: 8px;
            font-size: 1.05rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 15px rgba(212, 165, 116, 0.3);
        }
        
        button:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 25px rgba(212, 165, 116, 0.4);
        }
        
        button:active:not(:disabled) {
            transform: translateY(0);
        }
        
        button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .info-card {
            display: flex;
            flex-direction: column;
        }
        
        .info-card h3 {
            color: var(--gold);
            margin-bottom: 20px;
            font-size: 1.2rem;
        }
        
        .feature-list {
            list-style: none;
            flex: 1;
        }
        
        .feature-list li {
            padding: 12px 0;
            border-bottom: 1px solid var(--border);
            color: var(--text-light);
            line-height: 1.6;
        }
        
        .feature-list li:last-child {
            border-bottom: none;
        }
        
        .feature-list strong {
            color: var(--gold);
            font-weight: 600;
        }
        
        #result {
            background: rgba(45, 74, 111, 0.5);
            border: 1px solid var(--border);
            border-radius: 15px;
            padding: 30px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
            display: none;
            animation: slideIn 0.4s ease;
            margin-bottom: 40px;
        }
        
        #result.show {
            display: block;
        }
        
        #result h2 {
            color: var(--gold);
            margin-bottom: 20px;
            font-size: 1.4rem;
        }
        
        .result-content {
            line-height: 1.8;
            color: var(--text-light);
            white-space: pre-wrap;
            word-wrap: break-word;
            background: rgba(26, 47, 74, 0.4);
            padding: 20px;
            border-radius: 10px;
            border-left: 3px solid var(--gold);
            max-height: 600px;
            overflow-y: auto;
        }
        
        .result-content::-webkit-scrollbar {
            width: 8px;
        }
        
        .result-content::-webkit-scrollbar-track {
            background: rgba(45, 74, 111, 0.3);
            border-radius: 10px;
        }
        
        .result-content::-webkit-scrollbar-thumb {
            background: var(--gold);
            border-radius: 10px;
        }
        
        .download-section {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        
        .download-section button {
            flex: 1;
        }
        
        .download-section button:nth-child(2) {
            background: rgba(212, 165, 116, 0.2);
            border: 1.5px solid var(--gold);
            color: var(--gold);
        }
        
        .download-section button:nth-child(2):hover {
            background: rgba(212, 165, 116, 0.3);
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            display: none;
            animation: fadeIn 0.3s ease;
        }
        
        .loading.show {
            display: block;
        }
        
        .spinner {
            border: 4px solid var(--border);
            border-top: 4px solid var(--gold);
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .error {
            background: rgba(231, 76, 60, 0.15);
            color: #ff8a80;
            padding: 15px;
            border-radius: 8px;
            margin-top: 15px;
            display: none;
            border-left: 3px solid #ff8a80;
        }
        
        .error.show {
            display: block;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            header h1 {
                font-size: 2rem;
            }
            
            .card, #result {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>💍 AI WEDDING PLANNER</h1>
            <p>Professional AI-Powered Wedding Planning & Coordination</p>
        </header>
        
        <div class="divider"></div>
        
        <div class="main-content">
            <div class="card form-card">
                <h2>📋 Wedding Details</h2>
                
                <div class="tab-buttons">
                    <button class="tab-btn active" data-tab="form-input">📝 Form Input</button>
                    <button class="tab-btn" data-tab="row-input">✏️ Quick Input</button>
                </div>
                
                <!-- Form Input Tab -->
                <div class="tab-content active" id="form-input">
                    <form id="plannerForm">
                        <div class="form-group">
                            <label for="origin">🏠 Origin City</label>
                            <input 
                                type="text" 
                                id="origin" 
                                name="origin" 
                                placeholder="e.g., London, Mumbai, New York"
                                required
                            >
                        </div>
                        
                        <div class="form-group">
                            <label for="destination">🎯 Destination</label>
                            <input 
                                type="text" 
                                id="destination" 
                                name="destination" 
                                placeholder="e.g., Paris, Jaipur, Bali"
                                required
                            >
                        </div>
                        
                        <div class="form-group">
                            <label for="guest_count">👥 Guest Count</label>
                            <input 
                                type="number" 
                                id="guest_count" 
                                name="guest_count" 
                                min="1" 
                                max="1000" 
                                value="100"
                                required
                            >
                        </div>
                        
                        <div class="form-group">
                            <label for="genre">🎵 Music Genre</label>
                            <select id="genre" name="genre" required>
                                <option value="">Select genre...</option>
                                <option value="jazz">Jazz</option>
                                <option value="classical">Classical</option>
                                <option value="pop">Pop</option>
                                <option value="bollywood">Bollywood</option>
                                <option value="rock">Rock</option>
                                <option value="reggae">Reggae</option>
                                <option value="electronic">Electronic</option>
                                <option value="indie">Indie</option>
                            </select>
                        </div>
                        
                        <button type="submit" id="submitBtn">🚀 Plan Wedding</button>
                    </form>
                </div>
                
                <!-- Row Input Tab -->
                <div class="tab-content" id="row-input">
                    <form id="rowForm">
                        <div class="form-group">
                            <label for="rowInput">✏️ Describe Your Wedding</label>
                            <textarea 
                                id="rowInput" 
                                name="rowInput" 
                                placeholder="Example: I am travelling from mumbai to jaipur with 100 people and music like genre is jazz"
                                required
                            ></textarea>
                            <p style="color: var(--gold-light); font-size: 0.85rem; margin-top: 10px;">
                                💡 Tip: Include origin city, destination, number of guests, and music genre
                            </p>
                        </div>
                        
                        <button type="submit" id="rowSubmitBtn">🚀 Plan Wedding</button>
                    </form>
                </div>
                
                <div class="error" id="error"></div>
            </div>
            
            <div class="card info-card">
                <h3>✨ Platform Features</h3>
                <ul class="feature-list">
                    <li><strong>✈️ Flight Intelligence:</strong> Real-time pricing & availability</li>
                    <li><strong>🏰 Venue Discovery:</strong> Curated premium venues with reviews</li>
                    <li><strong>🎵 Music Curation:</strong> Genre-specific playlist selection</li>
                    <li><strong>💰 Budget Planning:</strong> Complete cost breakdown</li>
                    <li><strong>📅 Timeline Management:</strong> Coordinated event milestones</li>
                    <li><strong>📊 Professional Reports:</strong> Downloadable wedding plans</li>
                </ul>
            </div>
        </div>
        
        <div class="loading" id="loading">
            <div class="spinner"></div>
            <h3>Planning Your Perfect Wedding...</h3>
            <p style="color: var(--gold-light); margin-top: 15px; font-size: 0.9rem;">
                Our AI agents are searching flights, venues, and music selections
            </p>
        </div>
        
        <div class="card" id="result">
            <h2>✅ Your Wedding Plan</h2>
            <div class="result-content" id="resultContent"></div>
            <div class="download-section">
                <button onclick="downloadResult()">📥 Download Plan</button>
                <button onclick="clearResult()">🔄 Start Over</button>
            </div>
        </div>
    </div>
    
    <script>
        const formTab = document.querySelector('[data-tab="form-input"]');
        const rowTab = document.querySelector('[data-tab="row-input"]');
        const formContent = document.getElementById('form-input');
        const rowContent = document.getElementById('row-input');
        const plannerForm = document.getElementById('plannerForm');
        const rowForm = document.getElementById('rowForm');
        const loading = document.getElementById('loading');
        const result = document.getElementById('result');
        const resultContent = document.getElementById('resultContent');
        const errorDiv = document.getElementById('error');
        
        // Tab switching
        formTab.addEventListener('click', () => {
            formTab.classList.add('active');
            rowTab.classList.remove('active');
            formContent.classList.add('active');
            rowContent.classList.remove('active');
            errorDiv.classList.remove('show');
        });
        
        rowTab.addEventListener('click', () => {
            rowTab.classList.add('active');
            formTab.classList.remove('active');
            rowContent.classList.add('active');
            formContent.classList.remove('active');
            errorDiv.classList.remove('show');
        });
        
        // Form Input
        plannerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const origin = document.getElementById('origin').value.trim();
            const destination = document.getElementById('destination').value.trim();
            const guest_count = document.getElementById('guest_count').value;
            const genre = document.getElementById('genre').value;
            
            if (!origin || !destination || !genre) {
                errorDiv.textContent = '⚠️ Please fill in all required fields';
                errorDiv.classList.add('show');
                return;
            }
            
            await submitPlan(origin, destination, guest_count, genre);
        });
        
        // Row Input
        rowForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const rowInput = document.getElementById('rowInput').value.trim();
            
            if (!rowInput) {
                errorDiv.textContent = '⚠️ Please enter wedding details';
                errorDiv.classList.add('show');
                return;
            }
            
            // Parse row input
            fetch('/parse-row-input', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ text: rowInput }),
            })
            .then(res => res.json())
            .then(data => {
                if (data.error) {
                    errorDiv.textContent = `⚠️ ${data.error}`;
                    errorDiv.classList.add('show');
                } else {
                    errorDiv.classList.remove('show');
                    submitPlan(data.origin, data.destination, data.guest_count, data.genre);
                }
            });
        });
        
        async function submitPlan(origin, destination, guest_count, genre) {
            errorDiv.classList.remove('show');
            loading.classList.add('show');
            result.classList.remove('show');
            
            try {
                const response = await fetch('/plan', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        origin,
                        destination,
                        guest_count,
                        genre,
                    }),
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    resultContent.textContent = data.result;
                    loading.classList.remove('show');
                    result.classList.add('show');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                } else {
                    errorDiv.textContent = `⚠️ ${data.error}`;
                    errorDiv.classList.add('show');
                    loading.classList.remove('show');
                }
            } catch (error) {
                errorDiv.textContent = `⚠️ ${error.message}`;
                errorDiv.classList.add('show');
                loading.classList.remove('show');
            }
        }
        
        function downloadResult() {
            const text = resultContent.textContent;
            const element = document.createElement('a');
            element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
            element.setAttribute('download', 'wedding_plan.txt');
            element.style.display = 'none';
            document.body.appendChild(element);
            element.click();
            document.body.removeChild(element);
        }
        
        function clearResult() {
            result.classList.remove('show');
            plannerForm.reset();
            rowForm.reset();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    </script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Flask Routes
# ---------------------------------------------------------------------------

@app.route("/", methods=["GET"])
def index():
    return render_template_string(INDEX_TEMPLATE)


@app.route("/parse-row-input", methods=["POST"])
def parse_row_input_route():
    """Parse natural language row input"""
    data = request.get_json()
    text = data.get("text", "").strip()
    
    origin, destination, guest_count, genre, error = parse_row_input(text)
    
    if error:
        return jsonify({"error": error}), 400
    
    return jsonify({
        "origin": origin,
        "destination": destination,
        "guest_count": guest_count,
        "genre": genre,
    }), 200


@app.route("/plan", methods=["POST"])
def plan_wedding():
    data = request.get_json()

    origin = data.get("origin", "").strip()
    destination = data.get("destination", "").strip()
    guest_count = data.get("guest_count", "100")
    genre = data.get("genre", "").strip()

    if not all([origin, destination, genre]):
        return jsonify({"error": "Missing required fields"}), 400

    user_request = (
        f"I'm from {origin} and I'd like a wedding in {destination} "
        f"for {guest_count} guests, {genre}-genre."
    )

    try:
        result = asyncio.run(run_wedding_planner(user_request))
        return jsonify({"result": result}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("\n" + "="*60)
    print("🎊 AI WEDDING PLANNER - PROFESSIONAL WITH ROW INPUT")
    print("="*60)
    print("\n📍 Visit: http://localhost:5000")
    print("\n💡 Features:")
    print("   • Form Input: Traditional field-by-field input")
    print("   • Quick Input: Natural language row input")
    print("\n📝 Quick Input Examples:")
    print("   • I am travelling from mumbai to jaipur with 100 people and jazz")
    print("   • From London to Paris, 50 guests, classical music")
    print("   • Delhi to Goa with 200 people, bollywood genre")
    print("\n💙 Color Scheme: Professional Dark Blue & Gold")
    print("\n⚠️  Press Ctrl+C to stop the server\n")
    print("="*60 + "\n")
    
    app.run(debug=True, host="0.0.0.0", port=5000)